import src.hmml as hmml
import unittest
import numpy as np
import statsmodels


class TestHmmlGa(unittest.TestCase):

    def setUp(self):
        p = 16
        n = 32
        d = 8
        X = np.random.rand(p, n)
        distributions = ['gaussian' for i in range(p)]
        self.hga = hmml.HmmlGa(X=X, d=d, distributions=distributions)

    def test_crossover(self):
        parents = np.array([['a1', 'a2'], ['b1', 'b2']])

        child = self.hga.crossover(parents)

        if child[0] == 'a1':
            np.testing.assert_array_equal(child, ['a1', 'b2'])
        else:
            np.testing.assert_array_equal(child, ['b1', 'a2'])

    def test_mutation_1(self):
        sequence = np.random.default_rng().integers(2, size=100)
        mutated = self.hga.mutate(sequence, 0)
        # 0 mutation probability therefore the seuquences are equal
        self.assertEqual(len(mutated), len(sequence))
        np.testing.assert_array_equal(mutated, sequence)

    def test_mutation_2(self):
        sequence = np.random.default_rng().integers(2, size=100)
        mutated = self.hga.mutate(sequence, 0.1)
        self.assertEqual(len(mutated), len(sequence))
        diff = (sequence == mutated)
        # sequences are not equal
        self.assertTrue(diff.tolist().count(False) > 0)

    def test_repair_sequence_1(self):
        sequence = np.array([0, 1, 0, 0, 0, 0])
        test = self.hga.repair_sequence(sequence)
        # sequence is unchanged
        np.testing.assert_array_equal(test, sequence)

    def test_repair_sequence_2(self):
        sequence = np.array([0, 0, 0, 0, 0, 0])
        test = self.hga.repair_sequence(sequence)
        self.assertTrue(1 in test)

    def test_fit_1(self):
        # test if minimization works. We do this by replacing fitness with the vector sum
        # by this the expected result is all zeros
        def alternative_fitness(x_i, sequence, distribution, scores_so_far):
            return {
                'hmml': sum(sequence),
                'beta_i': None,
                'phi_i': None
            }

        self.hga.get_fitness = alternative_fitness
        self.hga.indices = [0]
        test = self.hga.fit()

        # NOTE: The sequence correction allows only a sequence with at least one 1.
        diff = (np.zeros([self.hga.p]) == test[0]['adjacency'])
        self.assertTrue(1 in test[0]['adjacency'])
        self.assertTrue(diff.tolist().count(False) == 1)

    def test_fit_2(self):
        self.hga.indices = [0]
        test = self.hga.fit()
        print(test)

    def test_get_fitness(self):
        self.hga.indices = [0]
        expected = 1234567890
        results_so_far = {7: expected}
        test = self.hga.get_fitness(self.hga.X[0], np.array([1, 1, 1]), 'normal', results_so_far)
        self.assertEqual(test, expected)

    def test_selection_1(self):
        population = np.array([[1, 1, 1, 0],
                               [0, 1, 1, 0],
                               [0, 1, 1, 0]])
        scores = np.array([2, 3, 2])

        expected = np.array([[0, 1, 1, 0],
                             [1, 1, 1, 0],
                             [0, 1, 1, 0]])
        test = self.hga.selection(population, scores)

        np.testing.assert_array_equal(test, expected)


if __name__ == '__main__':
    """Run the test with `python -m unittest tests.test_hmmlga
    """
    unittest.main()
