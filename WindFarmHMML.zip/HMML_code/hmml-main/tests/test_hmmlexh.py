import src.hmml as hmml
import unittest
import numpy as np
import statsmodels


class TestHmmlExh(unittest.TestCase):

    def setUp(self):
        p = 10
        n = 32
        d = 8
        X = np.random.rand(p, n)
        distributions = ['gaussian' for i in range(p)]
        self.hexh = hmml.HmmlExh(X=X, d=d, distributions=distributions)

    def test_fit_1(self):
        # test if minimization works. We do this by replacing fitness with the vector sum
        # by this the expected result is all zeros
        def alternative_fitness(x_i, sequence, distribution):
            return {
                'hmml': sum(sequence),
                'beta_i': None,
                'phi_i': None
            }

        self.hexh.get_fitness = alternative_fitness
        self.hexh.indices = [0]
        test = self.hexh.fit()

        # NOTE: The sequence correction allows only a sequence with at least one 1.
        diff = (np.zeros([self.hexh.p]) == test[0]['adjacency'])
        self.assertTrue(1 in test[0]['adjacency'])
        self.assertTrue(diff.tolist().count(False) == 1)

    def test_fit_2(self):
        self.hexh.indices = [0]
        test = self.hexh.fit()
        print(test)



if __name__ == '__main__':
    """Run the test with `python -m unittest tests.test_hmmlga
    """
    unittest.main()
