import src.hmml as hmml
import unittest
import math
import numpy as np
import statsmodels


class TestHmml(unittest.TestCase):

    def setUp(self):
        n = 10
        p = 8
        d = 3
        x_i = np.random.rand(n) + 1
        X = np.random.rand(p, n) + 1
        gamma_i = np.array([0, 1, 4])
        k_i = len(gamma_i)
        self.h = hmml.Hmml(x_i=x_i, X=X, gamma_i=gamma_i, d=d, distribution='gaussian')

        self.X_i = np.random.rand((self.h.n - self.h.d), self.h.d * self.h.k_i)
        self.beta_i = np.random.rand(self.h.d * self.h.k_i)
        self.Xbeta_i = np.matmul(self.X_i, self.beta_i.transpose())
        self.phi_i = np.random.rand() * 2

    def test_lagged_Xi_1(self):
        self.h.d = 2
        self.h.gamma_i = [0, 2, 3]
        self.h.p = 4
        self.h.n = 5

        self.h.X = np.array(
                ['x_{}_{}'.format(i, j)
                 for i in range(1, self.h.p + 1)
                 for j in range(1, self.h.n + 1)]
            ).reshape((self.h.p, self.h.n))

        test = self.h.get_Xgamma_i()

        desired = np.array([['x_1_2', 'x_1_1', 'x_3_2', 'x_3_1', 'x_4_2', 'x_4_1'],
                            ['x_1_3', 'x_1_2', 'x_3_3', 'x_3_2', 'x_4_3', 'x_4_2'],
                            ['x_1_4', 'x_1_3', 'x_3_4', 'x_3_3', 'x_4_4', 'x_4_3']])

        self.assertEqual(test.shape, (self.h.n - self.h.d, self.h.d * len(self.h.gamma_i)))
        np.testing.assert_array_equal(test, desired)

    def test_lagged_Xi_2(self):
        self.h.p = 4
        self.h.d = 1
        self.h.gamma_i = [0]
        self.h.n = 5

        self.h.X = np.array(
                ['x_{}_{}'.format(i, j)
                 for i in range(1, self.h.p + 1)
                 for j in range(1, self.h.n + 1)]
            ).reshape((self.h.p, self.h.n))

        test = self.h.get_Xgamma_i()

        desired = np.array([['x_1_1'],
                            ['x_1_2'],
                            ['x_1_3'],
                            ['x_1_4']])

        self.assertEqual(test.shape, (self.h.n - self.h.d, self.h.d * len(self.h.gamma_i)))
        np.testing.assert_array_equal(test, desired)

    def test_lagged_Xi_3(self):
        self.h.p = 4
        self.h.gamma_i = list(range(self.h.p))
        self.h.n = 5    

        self.h.X = np.array(
                ['x_{}_{}'.format(i, j)
                 for i in range(1, self.h.p + 1)
                 for j in range(1, self.h.n + 1)]
            ).reshape((self.h.p, self.h.n))

        test = self.h.get_Xgamma_i()

        desired = np.array([['x_1_3', 'x_1_2', 'x_1_1', 'x_2_3', 'x_2_2', 'x_2_1', 'x_3_3', 'x_3_2',
                             'x_3_1', 'x_4_3', 'x_4_2', 'x_4_1'],
                            ['x_1_4', 'x_1_3', 'x_1_2', 'x_2_4', 'x_2_3', 'x_2_2', 'x_3_4', 'x_3_3',
                             'x_3_2', 'x_4_4', 'x_4_3', 'x_4_2']])

        self.assertEqual(test.shape, (self.h.n - self.h.d, self.h.d * self.h.p))
        np.testing.assert_array_equal(test, desired)

    def test_Gaussian_Wi(self):
        desired = np.identity(self.h.n - self.h.d)

        self.h.distribution = 'gaussian'
        test = self.h.get_Wi(self.Xbeta_i, self.phi_i)

        self.assertEqual(test.shape, (self.h.n - self.h.d, self.h.n - self.h.d))
        np.testing.assert_array_equal(test, desired)

    def test_binomial_Wi(self):
        desired = np.diag([
            math.exp(i)/((1+math.exp(i))**2)
            for i
            in self.Xbeta_i
        ])

        self.h.distribution = 'binomial'
        test = self.h.get_Wi(self.Xbeta_i, self.phi_i)

        np.testing.assert_almost_equal(test, desired)
        self.assertEqual(test.shape, (self.h.n - self.h.d, self.h.n - self.h.d))

    def test_poisson_Wi_1(self):
        phi_i = 1.0

        desired = np.diag([
            math.exp(i)
            for i
            in self.Xbeta_i
        ])

        self.h.distribution = 'poisson'
        test = self.h.get_Wi(self.Xbeta_i, phi_i)

        np.testing.assert_almost_equal(test, desired)
        self.assertEqual(test.shape, (self.h.n - self.h.d, self.h.n - self.h.d))

    def test_poisson_Wi_2(self):
        desired = np.diag([
            (self.h.x_i[self.h.d + i] - math.exp(self.Xbeta_i[i]))**2
            for i
            in range(self.h.n - self.h.d)
        ])

        self.h.distribution = 'poisson'
        test = self.h.get_Wi(self.Xbeta_i, self.phi_i)

        np.testing.assert_almost_equal(test, desired)
        self.assertEqual(test.shape, (self.h.n - self.h.d, self.h.n - self.h.d))

    def test_gamma_Wi(self):
        desired = np.diag([
            (1 / self.Xbeta_i[i])**2
            for i
            in range(self.h.n - self.h.d)
        ])

        self.h.distribution = 'gamma'
        test = self.h.get_Wi(self.Xbeta_i, self.phi_i)

        np.testing.assert_almost_equal(test, desired)
        self.assertEqual(test.shape, (self.h.n - self.h.d, self.h.n - self.h.d))

    def test_inverse_Gaussian_Wi(self):
        desired = np.diag([
            1 / self.Xbeta_i[i]
            for i
            in range(self.h.n - self.h.d)
        ])

        self.h.distribution = 'inverse_gaussian'
        test = self.h.get_Wi(self.Xbeta_i, self.phi_i)

        np.testing.assert_almost_equal(test, desired)
        self.assertEqual(test.shape, (self.h.n - self.h.d, self.h.n - self.h.d))

    def test_Gaussian_Li(self):
        temp_sum = 0.0
        for t in range(self.h.d, self.h.n):
            temp_sum += math.pow(self.h.x_i[t] - self.Xbeta_i[t - self.h.d], 2)
        desired = (-(self.h.n - self.h.d)/2 * math.log(2 * math.pi * self.phi_i)
                   - 1 / (2 * self.phi_i) * temp_sum)

        self.h.distribution = 'gaussian'
        test = self.h.get_Li(self.Xbeta_i, self.phi_i)
        np.testing.assert_almost_equal(test, desired)

    def test_binomial_Li_1(self):
        self.h.n = 4
        self.h.d = 3
        self.h.x_i = np.arange(self.h.n)

        Xgamma_i = np.arange((self.h.n - self.h.d) * self.h.d * self.h.k_i).reshape(
            ((self.h.n - self.h.d), self.h.d * self.h.k_i))
        beta_i = np.arange(self.h.d * self.h.k_i)
        Xbeta_i = np.matmul(Xgamma_i, np.transpose(beta_i))

        desired = self.h.x_i[-1] * Xbeta_i[-1] \
            - math.log(1 + math.exp(Xbeta_i[-1]))

        self.h.distribution = 'binomial'
        test = self.h.get_Li(Xbeta_i, self.phi_i)
        np.testing.assert_almost_equal(test, desired)

    def test_binomial_Li_2(self):
        desired = 0.0
        for t in range(self.h.d, self.h.n):
            desired += self.h.x_i[t] * self.Xbeta_i[t - self.h.d] \
                - math.log(1 + math.exp(self.Xbeta_i[t - self.h.d]))

        self.h.distribution = 'binomial'
        test = self.h.get_Li(self.Xbeta_i, self.phi_i)
        np.testing.assert_almost_equal(test, desired)

    def test_poisson_Li(self):
        self.h.x_i = np.random.randint(1, 16, self.h.n)

        desired = 0.0
        for t in range(self.h.d, self.h.n):
            desired += (self.h.x_i[t] * self.Xbeta_i[t - self.h.d]
                        - math.exp(self.Xbeta_i[t - self.h.d])
                        - math.log(math.factorial(self.h.x_i[t])))

        self.h.distribution = 'poisson'
        test = self.h.get_Li(self.Xbeta_i, self.phi_i)
        np.testing.assert_almost_equal(test, desired)

    def test_gamma_Li(self):
        kappa_i = self.phi_i
        mu_i = 1 / self.Xbeta_i

        desired = 0.0
        for t in range(self.h.d, self.h.n):
            desired += ((1/kappa_i - 1) * math.log(self.h.x_i[t])
                        - self.h.x_i[t] / (kappa_i * (mu_i[t - self.h.d]))
                        - math.log(kappa_i * mu_i[t - self.h.d]) / kappa_i
                        - math.log(math.gamma(1 / kappa_i)))

        self.h.distribution = 'gamma'
        test = self.h.get_Li(self.Xbeta_i, self.phi_i)
        np.testing.assert_almost_equal(test, desired)

    def test_inverse_Gaussian_Li(self):
        mu_i = self.Xbeta_i
        zeta_i = self.phi_i

        desired = 0.0
        sum2 = 0.0
        prod1 = 1.0
        for t in range(self.h.d, self.h.n):
            sum2 += ((self.h.x_i[t] - mu_i[t - self.h.d])**2
                     / (mu_i[t - self.h.d]**2 * self.h.x_i[t]))
        for t in range(self.h.d, self.h.n):
            prod1 *= (math.exp(- sum2 / (2 * zeta_i))
                      / (2 * math.pi * zeta_i * self.h.x_i[t]**3))
        desired = math.log(prod1)

        self.h.distribution = 'inverse_gaussian'
        test = self.h.get_Li(self.Xbeta_i, self.phi_i)
        np.testing.assert_almost_equal(test, desired)

    def test_mml_1(self):
        np.random.seed(0)  # Can have a math domain error in log function. Fix seed to minimize risk
                           # of error. Note that sometimes an error occurs nethertheless. Probably
                           # du to numerical issues.
        L_i = np.random.rand()
        W_i = np.random.rand(self.h.n - self.h.d, self.h.n - self.h.d)
        lambda_i = np.random.rand() + 1
        Sigma_i = np.identity(self.h.d * self.h.k_i)

        desired = (
            - L_i
            + (
                math.log(
                    np.linalg.det(
                        np.matmul(np.matmul(np.transpose(self.X_i), W_i), self.X_i)
                        + lambda_i * Sigma_i
                    )
                )
            ) / 2
            + self.h.k_i / 2 * math.log(2*math.pi/lambda_i)
            + (
                lambda_i / (2 * self.phi_i)
                * np.matmul(np.matmul(np.transpose(self.beta_i), Sigma_i), self.beta_i)
            )
            + math.log(self.h.n - self.h.d) / 2
            - (self.h.k_i + 1) / 2 * math.log(2 * math.pi)
            + math.log((self.h.k_i + 1) * math.pi) / 2
        )

        test = self.h.get_mml(L_i, self.beta_i, self.phi_i, lambda_i, self.X_i, W_i)
        np.testing.assert_almost_equal(test, desired)

    def test_hmml(self):
        self.h.fit()
        # TODO: complete test but it is good to know it runs through.


if __name__ == '__main__':
    """Run the test with `python -m unittest tests.test_hmml
    """
    unittest.main()
