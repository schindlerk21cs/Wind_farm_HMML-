import src.hmml.hmmlsearch as hmmlsearch
import unittest
import numpy as np
import statsmodels


class HmmlSearchTestInstance(hmmlsearch.HmmlSearch):
    def fit(self):
        return None


class TestHmmlSearch(unittest.TestCase):

    def setUp(self):
        p = 16
        n = 32
        d = 8
        X = np.random.rand(p, n)
        distributions = ['gaussian' for i in range(p)]
        self.hs = HmmlSearchTestInstance(X=X, d=d, distributions=distributions)

    def test_get_binary_sequence_1(self):
        test = self.hs.get_binary_sequence(6, 8)
        expected = np.array([0, 0, 1, 0, 0, 0])

        np.testing.assert_array_equal(test, expected)

    def test_get_binary_sequence_2(self):
        test = self.hs.get_binary_sequence(6, 46)
        expected = np.array([1, 0, 1, 1, 1, 0])

        np.testing.assert_array_equal(test, expected)

    def test_gamma_from_sequence_1(self):
        sequence = [0, 1, 0, 0, 1, 0, 0, 1, 0]
        expected = [1, 4, 7]

        test = self.hs.get_gamma_from_sequence(sequence)
        np.testing.assert_array_equal(test, expected)

    def test_gamma_from_sequence_2(self):
        sequence = [1, 0, 0, 1, 1, 0, 0, 0, 1]
        desired = [0, 3, 4, 8]

        test = self.hs.get_gamma_from_sequence(sequence)
        np.testing.assert_array_equal(test, desired)


if __name__ == '__main__':
    """Run the test with `python -m unittest tests.test_hmmlga
    """
    unittest.main()
