import numpy as np
import math
from abc import ABC, abstractmethod
from . import hmml


class HmmlSearch(ABC):

    def __init__(self,
                 X,
                 d,
                 distributions,
                 indices=None):
        """Search algorithm for finding the adjacency matrix with minimum hmml.

        Implementation of Schindlerova, Plant - Heterogeneous Graphical Granger Causality
        by Minimum Message Length


        Parameters
        ----------
        X : numpy.ndarray
            Matrix of size (pXn) where row i is the time series and column j the time instance,
        d : int
            Time lag d >= 1.
        distributions : list
            The distributions type of each time series. List must have length p. Available options
            are 'gaussian', 'binomial, 'poisson', 'gamma' and 'inverse_gaussian'.
        indices : iterable, optional
            List of target time series 1 <= i <= p. If None than all time series are explored. By
            default None.
        """
        self.X = X
        self.p = X.shape[0]
        self.n = X.shape[1]
        self.d = d
        self.distributions = distributions
        if indices is None:
            # if no index is given, search granger causalities for all time series
            indices = list(range(self.p))
        self.indices = indices
        self.results = None

    @abstractmethod
    def fit(self):
        ...

    def get_binary_sequence(self, length, value):
        """Return a binary array representation of the given value.

        Parameters
        ----------
        length : int
            Length of the sequence.
        value : int
            Integer value.

        Returns
        -------
        numpy.ndarray
            Binary sequence array.
        """
        return np.array([int(i) for i in '{:0{}b}'.format(value, length)])

    def get_int_from_binary_sequence(self, sequence):
        """Takes a sequence and converts it to an unsigned integer.

        Parameters
        ----------
        sequence : numpy.ndarray
            Binary sequency array.

        Returns
        -------
        int
            Integer representation.
        """
        return int(np.array2string(sequence, separator='')[1:-1], 2)

    def get_gamma_from_sequence(self, Qi):
        """Returns gamma for a given binary sequence Qi

        Qi corresponds to a gamma, so that it has ones in the positions of the
        indices of covariates from gamma and zero otherwise.
        gamma is a subset of Gamma={1,...,p} and denotes indices of regressor variables.

        Parameters
        ----------
        sequence : numpy.ndarray
            Binary sequence

        Returns
        -------
        list
            gamma
        """
        return [j for j in range(len(Qi)) if Qi[j] == 1]

    def get_fitness(self, x_i, sequence, distribution):
        """Get fitness score of the given sequence Qi.

        Parameters
        ----------
        x_i : numpy.ndarray
            Time series i.
        sequence : numpy.ndarray
            Binary sequence.
        distribution: string
            Distribution type of x_i.

        Returns
        -------
        float
            HMML score
        """
        gamma_i = self.get_gamma_from_sequence(sequence)
        h = hmml.Hmml(x_i, self.X, gamma_i, self.d, distribution)
        return h.fit()

    def is_it_new_best(self, new_hmml, old_hmml, new_sequence, old_sequence):
        """Performs check if the new found solution is better than the old solution. New is better
        if new hmml is less than old_hmml or if new_hmml is (almost) equeal to old_hmml and 
        new sequence length is smaller than the old sequence length.

        Parameters
        ----------
        new_hmml : float
        old_hmml : float
        new_sequence : list
        old_sequence : list

        Returns
        -------
        bool
            True if new is better than old, False otherwise.
        """
        if new_hmml < old_hmml:
            return True
        if math.isclose(new_hmml, old_hmml) and np.sum(new_sequence) < np.sum(old_sequence):
            return True
        return False
