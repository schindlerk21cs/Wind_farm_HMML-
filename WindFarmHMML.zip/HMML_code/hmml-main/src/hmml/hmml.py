import numpy as np
import math
import statsmodels.api as sm
import scipy


class Hmml():
    """Minimum Message Length for gamma_i.

    Implementation of algorithm 1 in Schindlerova, Plant - Heterogeneous Graphical Granger
    Causality by Minimum Message Length
    """

    def __init__(self,
                 x_i,  # Target time series of length n
                 X,  # p series is the matrix of length n
                 gamma_i=None,  # gamma_i
                 d=None,  # time lag d
                 distribution='Gaussian'
                 ):
        """Minimum Message Length for gamma_i.

        Implementation of Algorithm 1 in Schindlerova, Plant - Heterogeneous Graphical Granger
        Causality by Minimum Message Length

        Parameters
        ----------
        x_i : numpy.ndarray
            Target time series i of length n.
        X : numpy.ndarray
            p time series of length n.
        gamma_i : list
            Subset of indices of regressor variables. If no value is given set {1,...,p} is used.
        d : int, optional
            Time lag d >= 1. If no value is given lag d is assumed to be n - 1.
        distribution : string, optional
            Distribution of time series x_i. Available options are 'gaussian', 'binomial, 'poisson',
            'gamma' and 'inverse_gaussian'. By default 'gaussian'.
        """

        self.x_i = x_i  # TODO: if x_i is an int interpret it as x_ith row in X
        self.X = X
        self.n = len(self.x_i)  # time instances per time series
        self.p = len(self.X)  # Number of time series
        if gamma_i is None:
            gamma_i = list(range(self.p))
        self.gamma_i = gamma_i
        self.k_i = len(self.gamma_i)  # Cardinality of gamma_i, k_i = |gamma_i|
        if d is None:
            d = self.n - 1
        self.d = d
        self.distribution = distribution.lower()

    def fit(self):
        """Compute hmml value. Returns hmml value of numpy.inf if no solution was found.

        Returns
        -------
        dict
            Dictionary with hmml value, coeficients beta_i and dispersion parameter phi_i.
        """
        # Construct the d-lagged matrix X(gamma_i) from time series with indices from gamma_i (9)
        Xgamma_i = self.get_Xgamma_i()

        # Set distribution dependent methods/parameters
        # Families have a link function. Not all link functions make are available for each family.
        # You can see available link functions by print(sm.genmod.families.family.<Family>.links)
        # For more details on statsmodels families see: https://www.statsmodels.org/stable/generated/statsmodels.genmod.generalized_linear_model.GLM.html
        # Generally speaking the default link functions seem to also achive the best results.
        if self.distribution == 'gaussian':  # Gaussian / normal distribution
            glm_family = sm.families.Gaussian()
            # sm.genmod.families.links.identity is default
        elif self.distribution == 'binomial':
            glm_family = sm.families.Binomial()
            # sm.genmod.families.links.logit is default
        elif self.distribution == 'poisson':
            glm_family = sm.families.Poisson()
            # sm.genmod.families.links.log is default
        elif self.distribution == 'gamma':
            glm_family = sm.families.Gamma()
            # sm.genmod.families.links.inverse_power is default
        elif self.distribution == 'inverse_gaussian':
            glm_family = sm.families.InverseGaussian()
            # sm.genmod.families.links.inverse_squared is default

        # Assign a non-default variance function by
        # glm_family.variance = sm.genmod.families.varfuncs.constant
        # See: https://www.statsmodels.org/stable/glm.html

        # Find initial solution beta(gamma_i) in linear model
        # mu_i = E(x_i^'|X_i) = eta_i(X_i beta_i^')x_i^t = X_{t,d}^{Lag} * beta_i' + epsilon_i^t
        # Because we can have distributions of various types (not only gaussian) solve beta_i
        # with a Genereralized Linear Model solver.
        try:
            model = sm.GLM(
                self.x_i[self.d:].transpose(),
                Xgamma_i, glm_family,
                missing='drop'
            )
            glm_results = model.fit()
            # method='IRLS',
            # wls_method='qr',  # qr, lstsq (default) or pinv, (lstsq and pinv are more robust in
                                # near-singular scenarios)
            # scale='X2',  # 'X2' (default), 'dev' or a float
            # maxiter=100

            # print(glm_results.summary())
            beta_i = glm_results.params
            # Get dispersion parameter phi_i
            # GLM results also provide the dispersion value phi_i.
            phi_i = glm_results.scale

        # except Exception:
        except sm.tools.sm_exceptions.PerfectSeparationError as err:
            # print(err)
            return {
                'hmml': np.inf,
                'beta_i': None,
                'phi_i': None
            }
        except ValueError as err:
            # Value error can be thrown because of invalid values (NaN, inf) in weights
            # print(err)
            return {
                'hmml': np.inf,
                'beta_i': None,
                'phi_i': None
            }

        # Comput matrix W_i and log-likelihood L_i.
        # Both depend on distribution (Gausian, binomial, ...) of x_i, see section 3.3.
        Xbeta_i = np.matmul(Xgamma_i, beta_i.transpose())
        W_i = self.get_Wi(Xbeta_i, phi_i)
        L_i = self.get_Li(Xbeta_i, phi_i)

        # Find optimal lambda_i by solving minimization problem for lambda_i.
        # lambda_i = scipy.optimize.minimize(__mml_optimizable_map, ())
        bounds = (0, 1E8)
        res = scipy.optimize.minimize_scalar(
            self.__optimize_mml,
            bounds=bounds,  # lambda_i is a positive real number but method does not seem to
                            # handle np.inf well
            method='bounded',
            args=(L_i, beta_i, phi_i, Xgamma_i, W_i)
            # options={'maxiter': 1000, 'disp': False}  # Additional solver options.
        )

        if res.success:
            lambda_i = res.x
            mml_opt = res.fun
        else:  # try a different solver
            res = scipy.optimize.minimize(
                self.__optimize_mml,
                1,
                bounds=[bounds],  # lambda_i is a positive real number
                method='Powell',  # Powell seems to be a robust solver for bounded problems
                args=(L_i, beta_i, phi_i, Xgamma_i, W_i)
            )
            if res.success:
                lambda_i = res.x[0]
                mml_opt = res.fun[0]
            else:  # If this was also not successful return None
                return {
                    'hmml': np.inf,
                    'beta_i': None,
                    'phi_i': None
                }

        # Compute HMML(x_i, X, gamma_i)
        # = I(x_i, beta_i_hat, phi_i_hat, lambda_i_hat, X_i, gamma_i) + I(gamma_i)
        # = (min(lambda_i) MML(x_i, beta_i, phi_i, lambda_i X(gamma_i), gamma_i)) + I(gamma_i)
        # return mml_opt + self.get_I_gamma_i()

        return {
            'hmml': mml_opt + self.get_I_gamma_i(),
            'beta_i': beta_i,
            'phi_i': phi_i
        }

    def get_Xgamma_i(self):
        """Returns lagged matrix X(gamma_i) as described in equation (9) in paper.
        X(gamma_i) is derived from (n-d)x(d * p) design matrix (7).

        Returns
        -------
        numpy.array
            Lagged matrix Xi as described in (9)
        """

        # NOTE: it may be worthwile to generate design matrix (7) once and only read
        # the necessary columns?

        rows = []
        for j in range(self.d, self.n):
            rows.append([self.X[i, t - 1]
                        for i in self.gamma_i
                        for t in range(j, j - self.d, -1)])

        return np.array(rows)

    def get_I_gamma_i(self):
        """Computes I(gamma_i) = log(p chooses k_i) + log(p + 1). See equation (12) in paper.

        Returns
        -------
        float
            I(gamma_i) value.
        """
        return math.log(math.comb(self.p, self.k_i)) + math.log(self.p + 1)

    def get_Wi(self, Xbeta_i, phi_i):
        """Returns the distribution dependend W_i matrix.

        Parameters
        ----------
        Xbeta : numpy.ndarray
            Vector Xbeta, product fo the d-lagged matrix X(gamma_i) of size (n-d)X(d*k_i) and vector
            beta(gamma_i) of size (d*k_i).
        phi_i : float
            Dispersion parameter phi_i.

        Returns
        -------
        numpy.ndarray
            (n-d)X(n-d) sized diagonal matrix W_i.
        """
        if self.distribution == 'gaussian':
            return self.__get_Wi_gaussian()
        if self.distribution == 'binomial':
            return self.__get_Wi_binomial(Xbeta_i)
        if self.distribution == 'poisson':
            return self.__get_Wi_poisson(Xbeta_i, phi_i)
        if self.distribution == 'gamma':
            return self.__get_Wi_gamma(Xbeta_i)
        if self.distribution == 'inverse_gaussian':
            return self.__get_Wi_inverse_gaussian(Xbeta_i)

    def get_Li(self, Xbeta_i, phi_i):
        """Returns the distribution dependend L_i value.

        Parameters
        ----------
        Xbeta : numpy.ndarray
            Vector Xbeta, product fo the d-lagged matrix X(gamma_i) of size (n-d)X(d*k_i) and vector
            beta(gamma_i) of size (d*k_i).
        phi_i : float
            Dispersion parameter phi_i.

        Returns
        -------
        numpy.ndarray
            (n-d)X(n-d) sized diagonal matrix W_i.
        """
        if self.distribution == 'gaussian':
            return self.__get_Li_gaussian(Xbeta_i, phi_i)
        if self.distribution == 'binomial':
            return self.__get_Li_binomial(Xbeta_i)
        if self.distribution == 'poisson':
            return self.__get_Li_poisson(Xbeta_i)
        if self.distribution == 'gamma':
            return self.__get_Li_gamma(Xbeta_i, phi_i)
        if self.distribution == 'inverse_gaussian':
            return self.__get_Li_inverse_gaussian(Xbeta_i, phi_i)

    def get_mml(self, L_i, beta_i, phi_i, lambda_i, Xgamma_i, W_i):
        """Returns the mimimum message length of set gamma_i. See equation (13) in paper.

        Parameters
        ----------
        L_i : float
            Log likelihood L_i depending on the density function of x_i
        beta_i : numpy.ndarray
            Vector of regression coefficiants of size (d * k_i).
        phi_i : float
            Dispersion parameter.
        lambda_i : float
            Weight of the adaptive Lasso penalty function.
        Xgamma_i : numpy.ndarray
            Lagged matrix X(gamma_i) as described in equation (9).
        W_i : numpy.ndarray
            (n-d)X(n-d) diagonal matrix depending on link function eta_i

        Returns
        -------
        float
            Minimum message length.
        """

        Sigma_i = np.identity(self.d * self.k_i)

        xwxs = np.linalg.det(
            np.matmul(
                np.matmul(
                    Xgamma_i.transpose(), W_i
                ), Xgamma_i
            ) + lambda_i * Sigma_i
        )

        # It can be that xwxs is smaller or equal to zero in which case its log can not be computed.
        # Don't let that happen and return nan instead.
        if xwxs <= 0:
            return np.nan

        return (
            - L_i
            + math.log(xwxs) / 2
            + self.k_i / 2 * math.log(2*np.pi/lambda_i)
            + (
                lambda_i / (2 * phi_i)
                * np.matmul(np.matmul(np.transpose(beta_i), Sigma_i), beta_i)  # TODO: can it be
                                                                               # optimized?
            )
            + math.log(self.n - self.d) / 2
            - (self.k_i + 1) / 2 * math.log(2 * math.pi)
            + math.log((self.k_i + 1) * math.pi) / 2
        )

    def __get_Wi_gaussian(self):
        """W_i identity matrix for the Gaussian distribution case.

        Return
        ------
        numpy.ndarray
            Diagonal matrix W_i of size (n-d)X(n-d).
        """
        return np.identity(self.n - self.d)

    def __get_Wi_binomial(self, Xbeta_i):
        """W_i matrix for the binomial distribution case, see equation (18) in paper.

        Parameters
        ----------
        Xbeta : numpy.ndarray
            Vector Xbeta, product fo the d-lagged matrix X(gamma_i) of size (n-d)X(d*k_i) and vector
            beta(gamma_i) of size (d*k_i).

        Return
        ------
        numpy.ndarray
            Diagonal matrix W_i of size (n-d)X(n-d).
        """
        return np.diag(np.exp(Xbeta_i) / np.square(1 + np.exp(Xbeta_i)))

    def __get_Wi_poisson(self, Xbeta_i, phi_i):
        """W_i matrix for the binomial distribution case, see equation (22) in paper.

        Parameters
        ----------
        Xbeta : numpy.ndarray
            Vector Xbeta, product fo the d-lagged matrix X(gamma_i) of size (n-d)X(d*k_i) and vector
            beta(gamma_i) of size (d*k_i).
        phi_i : float
            Dispersion parameter phi_i.

        Return
        ------
        numpy.ndarray
            Diagonal matrix W_i of size (n-d)X(n-d).
        """
        if math.isclose(phi_i, 1):  # dispersion phi_i = 1
            return np.diag(np.exp(Xbeta_i))
        else:  # phi_i is over- or underdispersed
            return np.diag(np.square(self.x_i[self.d:] - np.exp(Xbeta_i)))

    def __get_Wi_gamma(self, Xbeta_i):
        """W_i matrix for the gamma distribution case, see equation (26) in paper.

        Parameters
        ----------
        Xbeta : numpy.ndarray
            Vector Xbeta, product fo the d-lagged matrix X(gamma_i) of size (n-d)X(d*k_i) and vector
            beta(gamma_i) of size (d*k_i).

        Return
        ------
        numpy.ndarray
            Diagonal matrix W_i of size (n-d)X(n-d).
        """
        return np.diag(1 / np.square(Xbeta_i))

    def __get_Wi_inverse_gaussian(self, Xbeta_i):
        """W_i matrix for the inverse Gaussian distribution case, see equation (29) in paper.

        Parameters
        ----------
        Xbeta : numpy.ndarray
            Vector Xbeta, product fo the d-lagged matrix X(gamma_i) of size (n-d)X(d*k_i) and vector
            beta(gamma_i) of size (d*k_i).

        Return
        ------
        numpy.ndarray
            Diagonal matrix W_i of size (n-d)X(n-d).
        """
        return np.diag(1 / Xbeta_i)

    def __get_Li_gaussian(self, Xbeta_i, phi_i):
        """L_i value for the Gaussian distribution case, see equation (15) in paper.

        Parameters
        ----------
        Xbeta : numpy.ndarray
            Vector Xbeta, product fo the d-lagged matrix X(gamma_i) of size (n-d)X(d*k_i) and vector
            beta(gamma_i) of size (d*k_i).
        phi_i : float
            Dispersion parameter phi_i.

        Returns
        -------
        float
            L_i value for Gaussian case.
        """
        return (
            - (self.n - self.d) / 2
            * math.log(2 * math.pi * phi_i)
            - 1 / (2 * phi_i)
            * np.sum((self.x_i[self.d:] - Xbeta_i)**2)
        )

    def __get_Li_binomial(self, Xbeta_i):
        """L_i value for the binomial distribution case, see equation (17) in paper.

        Parameters
        ----------
        Xbeta : numpy.ndarray
            Vector Xbeta, product fo the d-lagged matrix X(gamma_i) of size (n-d)X(d*k_i) and vector
            beta(gamma_i) of size (d*k_i).

        Returns
        -------
        float
            L_i value for binomial case.
        """
        # NOTE: Vector X_beta has size n-d and the first position in the vector corresponds to the
        # d-th time instance
        # TODO: consider the more robust sandwich estimate estimate (19)
        return np.sum(self.x_i[self.d:] * Xbeta_i - np.log(1 + np.exp(Xbeta_i)))

    def __get_Li_poisson(self, Xbeta_i):
        """L_i value for the poisson distribution case, see equation (21) in paper.

        Parameters
        ----------
        Xbeta : numpy.ndarray
            Vector Xbeta, product fo the d-lagged matrix X(gamma_i) of size (n-d)X(d*k_i) and vector
            beta(gamma_i) of size (d*k_i).

        Returns
        -------
        float
            L_i value for binomial case.
        """
        # NOTE: Factorial can easily produce a value that will later overflow when converted to int.
        fact = scipy.special.factorial(self.x_i[self.d:])
        if len(fact[fact > np.iinfo(np.int64).max]):
            return np.nan
        # Alternative: Avoid this problem by converting the overflow value to the largest possible
        # int64 value. np.inf is not an option as it can not be an int.
        # fact[fact > np.iinfo(np.int64).max] = np.iinfo(np.int64).max
        return np.sum(self.x_i[self.d:] * Xbeta_i
                      - np.exp(Xbeta_i)  # TODO QUESTION: (21) says we take Xbeta_i positions
                                         # d+1 ... n, but thats not possible? Xbeta_i is (n-d)
                                         # sized vector
                      - np.log(fact.astype(np.int64)))  # convert to int, otherwise error possible

    def __get_Li_gamma(self, Xbeta_i, phi_i):
        """L_i value for the gamma distribution case, see equation (25) in paper.

        Parameters
        ----------
        Xbeta : numpy.ndarray
            Vector Xbeta, product fo the d-lagged matrix X(gamma_i) of size (n-d)X(d*k_i) and vector
            beta(gamma_i) of size (d*k_i).
        phi_i : float
            Dispersion parameter phi_i.

        Returns
        -------
        float
            L_i value for binomial case.
        """
        try:
            return np.sum((1 / phi_i - 1) * np.log(self.x_i[self.d:])
                          - self.x_i[self.d:] / (phi_i * (1 / Xbeta_i))
                          - np.log(phi_i / Xbeta_i) / phi_i
                          - math.log(math.gamma(1 / phi_i)))
        except OverflowError as err:  # Overflow error if phi_i is very small.
            return np.nan
        except ValueError as err:  # ValueError possible in log
            return np.nan

    def __get_Li_inverse_gaussian(self, Xbeta_i, phi_i):
        """L_i value for the inverse Gaussian distribution case, see equation (28) in paper.

        Parameters
        ----------
        Xbeta : numpy.ndarray
            Vector Xbeta, product fo the d-lagged matrix X(gamma_i) of size (n-d)X(d*k_i) and vector
            beta(gamma_i) of size (d*k_i).
        phi_i : float
            Dispersion parameter phi_i.

        Returns
        -------
        float
            L_i value for binomial case.
        """
        sum2 = np.sum((self.x_i[self.d:] - Xbeta_i)**2 / (Xbeta_i**2 * self.x_i[self.d:]))

        return np.sum(- math.log(2 * math.pi * phi_i)
                      - 3 * np.log(self.x_i[self.d:])
                      - sum2 / (2 * phi_i))

    def __optimize_mml(self, lambda_i, *args):
        """Scipy.optimize.minimize requires functions to be of form f(x, *args). This provides an
        function that is usable by scipys optimize algorithms.

        Parameters
        ----------
        lambda_i : float
            Dispersion parameter.
        *args : tuple
            Tuple of get_mml arguments passed on in the following order:
            L_i, beta_i, phi_i, Xgamma_i, W_i

        Returns
        -------
        float
            Minimum message length.
        """
        mml = self.get_mml(args[0], args[1], args[2], lambda_i, args[3], args[4])

        # Can happen that nan is returned. Because we have a minimization problem treat this as an
        # imposible large value.
        if np.isnan(mml):
            return np.inf
        return mml
