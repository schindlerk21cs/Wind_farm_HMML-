import numpy as np
from . import hmmlsearch


class HmmlExh(hmmlsearch.HmmlSearch):
    """Find minimum message length heterogeneous graphical granger model by exhaustive search as
    described in Schindlerova, Plant - Heterogeneous Graphical Granger Causality by Minimum Message
    Length.
    """

    def fit(self):
        """Searches HMML exhaustively.

        Returns
        -------
        list
            List of results for the given indices. Each list element is a dictionary with target 
            index, lag, distribution, adjacency sequence, hmml score, coefficients beta_i and 
            dispersion parameter ph_i.
        """

        # output
        # Adj = []  # adjacency matrix of the output causal graph;
        results = []  # adjacency matrix of the output causal graph;

        for i, target_index in enumerate(self.indices):
            # print('_____\nrunning index {}\n-----'.format(i))

            best_result = {'index': target_index, 'lag': self.d,
                           'distribution': self.distributions[i],
                           'adjacency': np.array([2**self.p]), 'hmml': np.inf}

            for j in range(1, 2**self.p):
                sequence = self.get_binary_sequence(self.p, j)
                score = self.get_fitness(self.X[target_index], sequence, self.distributions[i])
                if self.is_it_new_best(
                    score['hmml'], best_result['hmml'], sequence, best_result['adjacency']
                ):
                    best_result['adjacency'] = sequence
                    best_result.update(score)

            # The i-th row of Adj: Adj_i := Q_i with min of (12) such that |Q_i| is minimum
            results.append(best_result)

        self.results = results
        return results
