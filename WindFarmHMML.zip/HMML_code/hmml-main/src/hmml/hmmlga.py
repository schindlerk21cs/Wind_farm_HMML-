import math
import numpy as np
from . import hmmlsearch


class HmmlGa(hmmlsearch.HmmlSearch):
    """Find mimimum message lenght heterogeneous graphical Granger model by genetic algorithm.
    Implementation of algorithm 2 in Schindlerova, Plant - Heterogeneous Graphical Granger Causality
    by Minimum Message Length
    """

    def __init__(self,
                 X,
                 d,
                 distributions,
                 indices=None,
                 population_size=None,
                 max_generations=None,
                 max_unchanged=None,
                 mutation_probability=None,
                 mutation_multiplier=1,
                 seed=None):
        """Genetic Algorithm minimizing the HMML

        Implementation of Schindlerova, Plant - Heterogeneous Graphical Granger Causality
        by Minimum Message Length


        Parameters
        ----------
        X : numpy.ndarray
            Matrix of size (pXn) where row i is the time series and column j the time instance,
        d : int
            Time lag d >= 1.
        distributions : list
            The distributions type of each time series. List must have length p. Available options
            are 'gaussian', 'binomial, 'poisson', 'gamma' and 'inverse_gaussian'.
        indices : iterable, optional
            List of target time series 1 <= i <= p. If None than all time series are explored. By
            default None.
        population_size : int, optional
            Population size per generation, by default None. If None than population_size = 2 * p.
        max_generations : int, optional
            Maximum number of generations at which the algorithm stops, by default None. If None
            than max_generations = 2 * p log(p).
        max_unchanged : int, optional
            Maximum number of generations that did not find a better hmml score, by default None.
            If None than max_unchanged = log(p).
        mutation_probability : float, optional
            Probability that element i in sequence will be mutated, by default None. If None
            mutation_probability = 1 / p.
        mutation_multiplier : int, optional
            Value at which the mutation_probability changes per generation, by default 1.
        seed : int, optional
            The seed for the random number generator, by default None.
        """

        super().__init__(X, d, distributions, indices)
        if population_size is None:
            population_size = 2 * self.p
        self.population_size = population_size
        if max_generations is None:
            max_generations = 2 * self.p * math.floor(math.log2(self.p))
        self.max_generations = max_generations
        if max_unchanged is None:
            max_unchanged = math.ceil(math.log2(self.p))
        self.max_unchanged = max_unchanged
        if mutation_probability is None:
            mutation_probability = 1 / self.p
        self.mutation_probability = mutation_probability
        self.mutation_multiplier = mutation_multiplier
        self.rng = np.random.default_rng(seed)

    def fit(self):
        """Algorithm 2. Search hmml optimium with genetic algorithm.

        Returns
        -------
        list
            List of results for the given indices. Each list element is a dictionary with target 
            index, lag, distribution, adjacency sequence, hmml score, coefficients beta_i and 
            dispersion parameter ph_i.
        """

        # output
        # Adj = []  # adjacency matrix of the output causal graph;
        results = []  # adjacency matrix of the output causal graph;

        for i, target_index in enumerate(self.indices):
            # print('_____\nrunning index {}\n-----'.format(i))
            # create initial population Q of size m at random
            # Q_i := boolean vector of length p corresponding to a given gamma
            # Note: X.shape[0] == p

            scores_so_far = {}

            Q = self.rng.integers(0, 2, size=[self.population_size, self.p])
            for j in range(self.population_size):
                Q[j] = self.repair_sequence(Q[j])

            mutation_probability = self.mutation_probability

            generation_scores = np.array([
                self.get_fitness(
                    self.X[target_index], Q[j], self.distributions[i], scores_so_far
                )
                for j in range(self.population_size)
            ])

            # select the new generation
            Q = self.selection(Q, np.array([j['hmml'] for j in generation_scores]))

            best_result = {'index': target_index, 'lag': self.d,
                           'distribution': self.distributions[i],
                           'adjacency': Q[0], 'hmml': np.inf}
            best_unchanged = 0

            for v in range(self.max_generations):

                # create m descendents by crossover and mutation
                Q = np.array([
                    self.repair_sequence(
                        self.mutate(
                            self.crossover(
                                self.parent_selection(Q)
                            ), mutation_probability
                        )
                    )
                    for j in range(self.population_size)
                ])

                # change mutation probability over time
                mutation_probability *= self.mutation_multiplier

                generation_scores = np.array([
                    self.get_fitness(
                        self.X[target_index], Q[j], self.distributions[i], scores_so_far
                    )
                    for j in range(self.population_size)
                ])

                # select the new generation
                Q = self.selection(Q, np.array([j['hmml'] for j in generation_scores]))

                # test if the fittest sequence has changed to previous generation
                if np.array_equal(Q[0], best_result['adjacency']):
                    best_unchanged += 1
                else:
                    best_result['adjacency'] = Q[0]
                    best_unchanged = 0

                if best_unchanged > self.max_unchanged:
                    break

            # Search all scores for the best result.
            for int_sequence, score in scores_so_far.items():
                sequence = self.get_binary_sequence(self.p, int_sequence)
                if self.is_it_new_best(
                    score['hmml'], best_result['hmml'], sequence, best_result['adjacency']
                ):
                    best_result['adjacency'] = sequence
                    best_result.update(score)

            # The i-th row of Adj: Adj_i := Q_i with min of (12) such that |Q_i| is minimum
            results.append(best_result)

        self.results = results
        return results

    def get_fitness(self, x_i, sequence, distribution, scores_so_far):
        """Get fitness score of the given sequence Qi. Looks up score in scores_so_far where scores
        for sequences calculated previously are stored.

        Parameters
        ----------
        x_i : numpy.ndarray
            Time series i.
        sequence : numpy.ndarray
            Binary sequence.
        distribution: string
            Distribution type of x_i.
        scores_so_far : numpy.ndarray
            Array where previously scores are stored. If the sequence is found it returns the score
            from the array rather than calculating it again. If not the hmml scores is calculated
            and stored in the array for future lookups.

        Returns
        -------
        float
            HMML score.
        """
        if self.get_int_from_binary_sequence(sequence) in scores_so_far.keys():
            return scores_so_far[self.get_int_from_binary_sequence(sequence)]
        else:
            score = super().get_fitness(x_i, sequence, distribution)
            scores_so_far[self.get_int_from_binary_sequence(sequence)] = score
            return score

    def selection(self, population, scores):
        """Select the next generation according to their fitness scores.

        Sort HMML(Q_i_j) ascendently and select the half with the lowest scores for next generation.
        Fitness is determined by lowest hmml score and if two scores are close by the shorter
        sequence.

        Parameters
        ----------
        population : numpy.ndarray
            Population at a given generation.
        scores : numpy.ndarray
            Score for each element in population.

        Returns
        -------
        numpy.ndarray
            Next generation
        """
        population_ml_rank = np.argsort(np.sum(population, axis=1))

        # NOTE: avoid overwriting population by making a temporary copy
        pmml = population[population_ml_rank]
        return pmml[np.argsort(scores[population_ml_rank], kind='stable')
                    [:int(self.population_size/2)]]

    def parent_selection(self, population):
        """Select two parents from a potential pool of candidates

        Returns
        -------
        numpy.ndarray
            Array with two parents (sequences).
        """
        parents = population[self.rng.choice(len(population), 2, replace=False)]
        return parents

    def crossover(self, parents):
        """One Point crossover operation on parents sequence to create a new sequence.

        Parameters
        ----------
        parents : numpy.ndarray
            Array with two sequences.

        Returns
        -------
        numpy.ndarray
            A new sequence descended from parents.
        """
        crossover_position = self.rng.integers(1, len(parents[0]))
        return np.append(parents[0, :crossover_position], parents[1, crossover_position:])

    def mutate(self, sequence, probability=None):
        """Mutates sequence at random position (bit flip inversion). Returns a new sequence.

        Parameters
        ----------
        sequence : numpy.ndarray
            Sequence to be mutated.
        probability : float
            probability with which an element in the sequence is mutated.

        Returns
        -------
        numpy.ndarray
            Mutated sequence
        """

        if probability is None:
            probability = 1 / len(sequence)

        return np.array([
            ((i + 1) % 2) if self.rng.random() < probability
            else i
            for i in sequence
        ])

    def repair_sequence(self, sequence):
        """A sequence must have at least one true value in its sequence. If this is not the case,
        a random sequence is created.

        Parameters
        ----------
        sequence : numpy.ndarray
            Sequence to check and if applicable repair.

        Returns
        -------
        numpy.ndarray
            Repaired sequence
        """

        if 1 not in sequence:
            return self.repair_sequence(self.rng.integers(0, 2, size=self.p))
        return sequence
