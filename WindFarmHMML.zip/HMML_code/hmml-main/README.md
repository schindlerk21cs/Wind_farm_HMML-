# Heterogenous Minimum Message Length

This work consist of a Python implementation of the heterogeneous graphical Granger causality by minimum message length algorithm presented in [Hlaváčková-Schindler Kateřina and Plant Claudia, Heterogeneous Graphical Granger Causality by Minimum Message Length'', Entropy, vol. 22, number 12, pp. , 2020.](https://www.mdpi.com/1099-4300/22/12/1400).

## Usage

The implementation has three main classes: Hmml, HmmlExh and HmmlGa. Hmml returns the HMML value for a given $\gamma_i$ and time series variables as described in algorithm (1) in [[1]](https://www.mdpi.com/1099-4300/22/12/1400). HmmlExh and HmmlGa are search algorithms finding $gamma_i$ for which hmml($gamma_i$) and $k_i$ is minimum. HmmlExh performs an exhaustive search while HmmlGa uses a genetic search algorithm approach.

### Searching for causal connections in vector auto-regressive models

Given pXn matrix _X_ of  _p_ time series of length _n_, a lag _d_, a list of _distributions_ from the set {'gaussian', 'binomial, 'poisson', 'gamma', 'inverse_gaussian'} and a set of _target indices_ with the variable index for which Granger causalities should be found. The distributions and target indices should have equal length and the ith distribution in the list determines the link function of the ith target indes.

Two search methods are available. HmmlExh performs exhaustive search, HmmlGa searches by using a genetic algorithm.

    >>> X.shape  # X is a VAR model with p variables and length n
    (p,n)
    >>> d = 6  # lag is 6
    >>> target_indices = [1,2]
    >>> distributions = ['gamma', 'gaussian']

    # Search for granager causalities using genetic search algorithm
    >>> import hmml.HmmlGa
    >>> hmmlga = hmml.HmmlGa(X, d, distributions, target_indices)
    >>> results = hmmlga.fit()

    >>> print(results)

Results is a list with each entry a dictionary with index of the target variable, lag, distribution, the causal adjacency vector to the target variable, the hmml value, coefficient matrix beta_i and dispersion parameters phi_i.

### Getting HMML value for a given gamma_i

Given pXn matrix _X_ of  _p_ time series of length _n_, a target time series *x_i*, lag _d_, a distribution element from the set of {'gaussian', 'binomial, 'poisson', 'gamma', 'inverse_gaussian'} and a gamma_i which is a subset of {1,..., p}.

    >>> h = hmml.Hmml(x_i, X, gamma_i, d, 'inverse_gaussian')
    >>> results = hmml.fit()
    >>> print(results)

Results is a dictionary with hmml value, coefficient matrix beta_i and dispersion parameters phi_i. HMML value is np.inf if no result was found.

For more information [read the docs](docs/build/text/index.txt).

## Requires

- [numpy](https://numpy.org/)
- [statsmodels](https://www.statsmodels.org)
- [scipy](https://scipy.org/)

## Build

    python -m build

build the hmml package and generates source archive (tar.gz) and built distribution (.whl) in dist/ directory.

    python -m pip install --editable .

puts a link to the module into your local environment (in conda this is `lib/python3.10/site-packages/hmml.egg-link). Therfore the package is installed in your project but any links take effect immediatly.

For more information on creating packages see [PyPa - Packaging Python Project User Guide](https://packaging.python.org/en/latest/tutorials/packaging-projects/) or [The Joy of Packaging - Making a Python Package](https://python-packaging-tutorial.readthedocs.io/en/latest/setup_py.html).

### Build docs

    cd docs
    make html

Requires [sphinx](https://www.sphinx-doc.org)

## Tests

Run test by

    python -m unittest discover -s tests -v
