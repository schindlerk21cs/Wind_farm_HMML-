hmml.hmmlsearch.HmmlSearch
==========================

.. autoclass:: hmml.hmmlsearch.HmmlSearch
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__
