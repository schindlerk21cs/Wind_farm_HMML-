.. HMML documentation master file, created by
   sphinx-quickstart on Fri May 20 22:30:57 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to HMML's documentation!
================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   hmml

Summary
=======

This work consist of a Python implementation of the heterogeneous graphical Granger causality by minimum message length algorithm presented in [Hlaváčková-Schindler Kateřina and Plant Claudia, Heterogeneous Graphical Granger Causality by Minimum Message Length'', Entropy, vol. 22, number 12, pp. , 2020.](https://www.mdpi.com/1099-4300/22/12/1400).

Classes
=======

.. toctree::
   :maxdepth: 3

   hmml.hmmlga
   hmml.hmmlexh
   hmml.hmml

==================

* :ref:`genindex`
* :ref:`search`

